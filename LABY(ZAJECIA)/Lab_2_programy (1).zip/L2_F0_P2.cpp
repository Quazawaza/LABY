// L2_F0_P2.cpp    Zagniezdzone instrukcje warunkowe if-else, if 
#include <iostream>  
using namespace std;

int main()
{ 
  int x, y, z;
  //-------------------------------------------------------------------------------------
  cout << "Podaj liczbe calkowita x: ";  cin >> x;                     // Linia 1
  cout << "Podaj liczbe calkowita y: ";  cin >> y;                     // Linia 2
  cout << "Podaj liczbe calkowita z: ";  cin >> z;                     // Linia 3
  if ( x > y)                                                          // Linia 4
  if (y <= z);                                                         // Linia 5
  else cout << "Wniosek : " << " # " <<endl;                           // Linia 6
 //---------------------------------------------------------------------------------------
 system("PAUSE");                                    
 return 0;
}
